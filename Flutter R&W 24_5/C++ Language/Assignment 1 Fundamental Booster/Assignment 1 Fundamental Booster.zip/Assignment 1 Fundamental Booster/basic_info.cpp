#include<iostream>
using namespace std;

int main()
{
    cout << "My Name is Manav Ramani." << endl;
    cout << "i was complete BCA." << endl;
    cout << "Contact Number : 7096584269" << endl;
    cout << "Email : manavpatel13402003@gmail.com" << endl;
    cout << "City : Jasdan" << endl;
    cout << "Pin Code : 360050" << endl;
    return 0;
}