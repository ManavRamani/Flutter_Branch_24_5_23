/*
    4. Program to find length of string using pointer :
*/

#include<stdio.h>
#include<string.h>
void main()
{
    char m[20],*p;

    printf("\n Enter Any String : ");
    scanf("%s",m);

    p=m;
    
    printf("n\ m Length is : %d",strlen(p));


}