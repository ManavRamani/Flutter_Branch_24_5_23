/*
    2. Write a program to print integer value of day of week using enum :
*/

#include<stdio.h>
enum day {Sunday=1,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday};
void  main()
{
    enum day;
    printf(" Sunday : %d\n",Sunday);
    printf(" Saturday : %d\n",Saturday);

}