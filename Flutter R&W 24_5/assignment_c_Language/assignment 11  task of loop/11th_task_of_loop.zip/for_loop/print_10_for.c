/* 1. WAP to Print 1 to 10 using for loop. */

#include <stdio.h>

void main()
{
    int i;
    for (i = 1; i <= 10; i++)
    {
        printf("%d\n", i);
    }
}