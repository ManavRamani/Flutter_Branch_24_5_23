/*
    2-Wap to convert string into uppercase :
*/

#include<stdio.h>
#include<string.h>

void main()
{
    char ch[10]={"Manav"};
    printf("\nch is : %s\n",ch);
    printf("Usercase : %s\n",strupr(ch));

}